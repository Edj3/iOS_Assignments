//
//  BookAssignmentLogicTests.h
//  BookAssignmentLogicTests
//
//  Created by Unbounded on 4/25/13.
//  Copyright (c) 2013 Unbounded. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>
#import "BABook.h"

@interface BookAssignmentLogicTests : SenTestCase

@end
