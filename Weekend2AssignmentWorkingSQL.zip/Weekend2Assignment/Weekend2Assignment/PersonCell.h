//
//  PersonCell.h
//  Weekend2Assignment
//
//  Created by Unbounded on 4/6/13.
//  Copyright (c) 2013 Unbounded. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PersonTableViewController.h"
@interface PersonCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *cellFirst;
@property (strong, nonatomic) IBOutlet UILabel *cellLast;

@end
