//
//  MyTableCell.h
//  SingletonAssignment
//
//  Created by Unbounded on 4/12/13.
//  Copyright (c) 2013 Unbounded. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableCell : UITableViewCell
@property (strong,nonatomic) UILabel *cellMovie;
@property (strong,nonatomic) UILabel *cellYear;

@end
